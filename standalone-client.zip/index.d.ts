declare module "nextjs-toploader";

declare module "react-hot-toast";
