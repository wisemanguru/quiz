import React from "react";
import Status from "./Status";

const page = () => {
  return <Status />;
};

export default page;
