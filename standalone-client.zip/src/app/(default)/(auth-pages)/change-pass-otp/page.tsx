import ChangePasswordForm from "@/features/auth/ChangePassOTPForm";
export default function VerifyOTP() {
  return (
    <div className="w-full pt-8 sm:pt-20 xl:px-10 2xl:px-[60px]">
      <ChangePasswordForm />
    </div>
  );
}
