import React from "react";
import Deposit from "./Deposit";

const page = () => {
  return <Deposit />;
};

export default page;
