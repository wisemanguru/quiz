/** @format */

import CoinHistory from "./CoinHIstory";

export default function page() {
  return <CoinHistory />;
}
