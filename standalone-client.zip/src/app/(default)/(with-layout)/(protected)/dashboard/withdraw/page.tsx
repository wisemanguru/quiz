import React from "react";
import Wallet from "./Wallet";

const page = () => {
  return <Wallet />;
};

export default page;
