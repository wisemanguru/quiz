/** @format */

import Withdraw from "./Withdraw";

export default function WithdrawPage() {
  return <Withdraw />;
}
