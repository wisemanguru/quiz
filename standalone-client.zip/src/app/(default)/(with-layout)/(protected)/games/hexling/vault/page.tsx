import VaultCalendar from "@/components/games/hexling/vault/vault-calendar";

export default async function HexlingVaultPage() {
  return (
    <>
      <div className="mx-auto w-full max-w-prose">
        <VaultCalendar />
      </div>
    </>
  );
}
