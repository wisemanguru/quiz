/** @format */

import Loader from "@/components/ui/Loader";

export default function Loading() {
  return <Loader />;
}
